﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using ToDoList.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ToDoList.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToDoController : ControllerBase
    {
        private static List<ToDoItem> items = new List<ToDoItem>();
        private static void AddItems()
        {
        }
        static ToDoController()
        {
            AddItems();
        }
        // GET: api/<ToDoController>
        [HttpGet]
        public IEnumerable<ToDoItem> Get()
        {
            return items;
        }

        // GET api/<ToDoController>/5
        [HttpGet("{id}")]
        public ToDoItem Get(int id)
        {
            foreach (ToDoItem item in items)
            {
                if (item.Id == id) { return item; }
            }
            return null;
        }

        // POST api/<ToDoController>
        [HttpPost]
        public void Post([FromBody] string Description)
        {
            int id = items.Count + 1;
            items.Add(new ToDoItem(id, Description));
        }

        // PUT api/<ToDoController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string Description)
        {
            foreach (ToDoItem item in items)
            {
                if (item.Id == id) 
                { item.Description = Description; return; }
            }
        }

        // DELETE api/<ToDoController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            foreach (ToDoItem item in items)
            {
                if (item.Id == id) { items.Remove(item); return; }
            }
        }        [HttpPut("SetCompleted/{id}")]
        public void SetCompleted(int id, [FromBody] bool isDone)
        {
            foreach (ToDoItem item in items)
            {
                if (item.Id == id) { item.IsDone(isDone); return; }
            }
        }
    }
}
