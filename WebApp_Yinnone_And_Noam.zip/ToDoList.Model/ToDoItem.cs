﻿namespace ToDoList.Model
{
    public class ToDoItem
    {
        public int MyProperty { get; set; }

        public int Id { get; set; }
        public string Description { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public bool IsComplete { get; set; }
        public ToDoItem() { }
        public ToDoItem(int id, string description)
        {
            Id = id;
            Description = description;
            Start = DateTime.Now;
            End = DateTime.MinValue;
            IsComplete = false;
        }
        public void IsDone(bool isDone)
        {
            IsComplete = isDone;

            if (IsComplete) 
            { 
                End = DateTime.Now;
            }

            else 
            {
                End = DateTime.MinValue;
            }
        }
    }
}
