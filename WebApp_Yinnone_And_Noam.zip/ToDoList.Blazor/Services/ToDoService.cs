﻿namespace ToDoList.Blazor.Services;
using ToDoList.Model;
using System.Net.Http;
using System.Diagnostics.Metrics;
using System.Text.Json;
using System;
using Microsoft.AspNetCore.Mvc;
using System.Text;


public class ToDoService
{
    const string URL = "https://localhost:7023/api/ToDo";
    private readonly HttpClient _httpClient;
    public ToDoService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }
    public async Task<List<ToDoItem>> Read()
    {

        string url = "https://localhost:7023/api/ToDo";

        var response = await _httpClient.GetAsync(url);
        response.EnsureSuccessStatusCode();

        var jsonString = await response.Content.ReadAsStringAsync();
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        };

        return JsonSerializer.Deserialize<List<ToDoItem>>(jsonString, options);
    }
    public async Task SetToCompleted(int id, bool isComplete)
    {
        var content = new StringContent(JsonSerializer.Serialize(isComplete), Encoding.UTF8, "application/json");
        var response = await _httpClient.PutAsync($"{URL}/SetCompleted/{id}/", content);
        response.EnsureSuccessStatusCode();
    }
    public async Task Create(string description)
    {
        var content = new StringContent(JsonSerializer.Serialize(description), Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync(URL, content);
        response.EnsureSuccessStatusCode();
    }
    public async Task Update(int id, string description)
    {
        var content = new StringContent(JsonSerializer.Serialize(description),
        Encoding.UTF8, "application/json");

        var response = await _httpClient.PutAsync($"{URL}/{id}", content);
        response.EnsureSuccessStatusCode();
    }
    public async Task Delete(int id)
    {
        var response = await _httpClient.DeleteAsync($"{URL}/{id}");
        response.EnsureSuccessStatusCode();
    }
}
